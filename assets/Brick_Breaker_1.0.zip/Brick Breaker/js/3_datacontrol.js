function createBrickArray(){
    array.nRow = Math.floor(Math.random()*3 +3);
    array.nCol = Math.floor(Math.random()*4 +4);
    var brickPaddingX = (canvas.width - array.nCol*brickWidth - 2*array.margin)/(array.nCol -1);
    var brickPaddingY = (canvas.height - array.nRow*brickHeight - array.margin - 0.4*canvas.height)/(array.nRow -1);

    for(r = 0; r < array.nRow; r++){ //creating a 2D array of bricks
		array.bricks[r] = [];
		for(c = 0; c < array.nCol; c++){
			array.bricks[r][c] = new Brick();
	
			var b = array.bricks[r][c];

			//assign a brick a its position on canvas
			b.x = (c*(brickWidth + brickPaddingX)) + array.margin;
			b.y = (r*(brickHeight + brickPaddingY)) + array.margin;
		
			//assign a brick a powerUp
			if( Math.floor(Math.random()*5) > 0){
				var powerUp = Math.floor(Math.random()*4 + 1);
			
				if(powerUp == 1){
					b.lives = Math.floor(Math.random()*4 +1);} //assign a brick a random number of lives ranging 1 to 4
				if(powerUp == 2){
					b.speedUp = Math.floor(Math.random()*2);} //either 0 or 1
				if(powerUp == 3){
					b.speedAlter = Math.floor(Math.random()*2);} //0 or 1
				if(powerUp == 4){
					b.alterPlatformSize = Math.floor(Math.random()*3);} //0, 1 or 2
			}
    	}
    }

}

function loadImages(){
	var padding = 20;

	assets.playbutton.img = document.getElementById("playbutton");
	assets.playbutton.y = canvas.height/4;

	assets.hwtoplbutton.img = document.getElementById("howtoplaybutton");
	assets.hwtoplbutton.y = assets.playbutton.y + assets.playbutton.height + padding;

	assets.aboutbutton.img = document.getElementById("aboutbutton");
	assets.aboutbutton.y = assets.hwtoplbutton.y + assets.hwtoplbutton.height + padding;

	assets.gameoverbutton.img = document.getElementById("gameover");
	assets.gameoverbutton.y = (canvas.height - assets.gameoverbutton.height)/2;

	assets.soundon.img = document.getElementById("soundonbutton");
	assets.soundon.width = 20;
	assets.soundon.height = 20;
	assets.soundon.x = (canvas.width - 30)/2;
	assets.soundon.y = 0;

	assets.soundoff.img = document.getElementById("soundoffbutton");
	assets.soundoff.width = 20;
	assets.soundoff.height = 20;
	assets.soundoff.x = (canvas.width - 30)/2;
	assets.soundoff.y = 0;

	assets.background.img = document.getElementById("background");

	assets.hwtoplscreen.img = document.getElementById("howtoplay");

	assets.pausescreen.img = document.getElementById("pausescreen");

	assets.aboutscreen.img = document.getElementById("aboutscreen");

	assets.sound = new Audio("media/beep.mp3");
}

function resetGame(){
    lives = 5;
	score.score = 0;
	score.game = 1;

	platform.height = 10;
	platform.width = 75;
	platform.posX = (canvas.width - platform.width)/2; //start position middle of screen
	platform.posY = canvas.height - platform.height;

	ball.radius = 20;
	ball.x = ball.prevx = canvas.width/2;
	ball.y = ball.prevy = platform.posY - ball.radius -15;
	ball.dx = (Math.round(Math.random())*2 -1) * Math.floor(Math.random()*5 +3);
	ball.dy = -Math.floor(Math.random()*5 +2);
	ball.playSound = 0;

	createBrickArray();
}
