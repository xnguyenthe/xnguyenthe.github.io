/*~~~~~INPUT~~~~~*/

//keys
document.addEventListener("keydown", keyDownHandler, false);
//mouse
document.addEventListener("mousemove", mouseMoveHandler, false);

function mouseclick(event) {
    //get x and y coordinates    
    var x = event.pageX - canvas.offsetLeft;
    var y = event.pageY - canvas.offsetTop;
    

	switch(screen){
		case 0: //opening screen
			if(x > assets.soundon.x && x < assets.soundon.x + assets.soundon.width && 
	       	   y > assets.soundon.y && y < assets.soundon.y + assets.soundon.height){
            if(sound == 1)
                sound = 0;
            else
                sound = 1;
        	}

			for(var button in assets){
            	if(x > assets[button].x && x < assets[button].x + assets[button].width &&
                   y > assets[button].y && y < assets[button].y + assets[button].height){
                	if(button == "playbutton"){ //new game button
						resetGame();                            
						screen = 1;
					}
                    if(button == "hwtoplbutton") //how to play button
                        screen = 3;
					if(button == "aboutbutton")
						screen = 5;

            	}
        	}
		break;
		case 1: //playing screen
			if(x > assets.soundon.x && x < assets.soundon.x + assets.soundon.width && 
	       	   y > assets.soundon.y && y < assets.soundon.y + assets.soundon.height){
            if(sound == 1)
                sound = 0;
            else
                sound = 1;
        	}
		break;
		case 2: //game over screen
			screen = 0;
		break;
		case 3: //how to play screen
			screen = 0;
		break;
		case 4: //pause screen
			screen = 1;
		break;
		case 5: //about screen
			screen = 0;
		break;
	}
}


function keyDownHandler(e){
    switch (screen){
		case 1:
			switch(e.keyCode){
				case 39: //right key
					platform.posX +=10; break;
				case 37: //left key
					platform.posX -= 10; break;
				case 80: //p key
					screen = 4; break;
				case 82: //r key
					screen = 0; break;
			}
		break;
		case 4:
			switch(e.keyCode){
				case 80:
					screen = 1;
				break;
				case 82:
					screen = 0;
				break;
			}
		break;
	}
}

/*~~~~~Ball and platform movement~~~~~*/
function mouseMoveHandler(e){ 
    var relativeX = e.clientX - canvas.offsetLeft;
    if(relativeX > 0 && relativeX < canvas.width){
		platform.posX = relativeX - platform.width/2;
    }
}

function moveBall(){
	ball.prevx = ball.x;
	ball.prevy = ball.y;
    ball.x += ball.dx;
    ball.y += ball.dy;
}

/*~~~~SCORE and GAME OVER~~~~*/
function isTopScore(){
    var topScore = 1;
    for(r = 0; r < array.nRow; r++)
	for(c = 0; c < array.nCol; c++)
	    if(array.bricks[r][c].lives > 0){
		topScore = 0;
		break; break;
	    }
		
    if(topScore){
		createBrickArray();
		ball.x = (2*platform.posX + platform.width)/2; //the average of the left and right edge of the platform 
		ball.y = platform.posY - ball.radius;
		score.game++;
    }
}

function isGameOver(){
    if(lives == 0){
		screen = 2;
        score.maxScore = score.score;
        score.maxGame = score.game;

        resetGame();
    }
}
