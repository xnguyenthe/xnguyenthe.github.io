function drawNewGameScreen(){
	assets.background.draw();
	drawSoundIcon();
	assets.playbutton.draw();
	assets.hwtoplbutton.draw();
	assets.aboutbutton.draw();
}

function drawHowToPlayScreen(){
	assets.hwtoplscreen.draw();
	drawSoundIcon();
}

function drawPlayScreen(){
	assets.background.draw(); //drawBackground();
    ball.draw(); //drawBall();
    platform.draw(); //drawPlatform();
	for(r = 0; r < array.nRow; r++)
		for(c = 0; c < array.nCol; c++)
	    	array.bricks[r][c].draw();    

	//drawBricks();
	drawScore();
    drawLives();
	drawSoundIcon();
	playSound();
}

function drawGameOverScreen(){
	assets.background.draw();
	assets.gameoverbutton.draw();
	ctx.fillText("Cleared Games: " + (score.maxGame-1) + " Score: " + score.maxScore, 5, 20);
}

function playSound(){
	if(sound == 1 && ball.playSound == 1){	
		assets.sound.play();
		ball.playSound = 0;
	}
}

function drawSoundIcon(){
	if(sound == 1){
		assets.soundon.draw();
	}
	else
		assets.soundoff.draw();
}

function drawScore(){
    ctx.font = "15pt Arial";
    ctx.fillStyle = "white";
    ctx.fillText("Game: " + score.game + " Score: " + score.score, 8, 20);
}

function drawLives(){
    ctx.font = "15pt Arial";
    ctx.fillStyle = "white";
    ctx.fillText("Lives: " + lives, canvas.width - 80, 20)
}
