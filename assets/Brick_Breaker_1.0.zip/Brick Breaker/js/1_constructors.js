var canvas = document.getElementById("theCanvas");
var ctx = canvas.getContext("2d"); //for rendering on the canvas

//images sounds etc.
function Image(){
	this.x;
	this.y;
	this.width;
	this.height;
	this.img;
	this.draw = function(){
		ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
	}
}
function Button(){
	this.x = canvas.width/4;
	this.width = canvas.width/2;
	this.height = canvas.height/6;
}
Button.prototype = new Image();
function Screen(){
	this.x = 0;
	this.y = 0;
	this.width = canvas.width;
	this.height = canvas.height;
}
Screen.prototype = new Image();

//the platform
function Platform(){
    this.height;
    this.width;
    this.posX;
    this.posY;

    this.draw = function(){
        ctx.beginPath();
    	ctx.rect(this.posX, this.posY, this.width, this.height);
    	ctx.fillStyle = "black";
    	ctx.fill();
    	ctx.closePath();    
    };
}

function Ball(){
    this.radius;
    this.x;
    this.y;
    this.prevx;
    this.prevy;
    
    //movement of the ball (speed)
	this.dx;
	this.dy;
	this.playSound;
	this.draw = function(){
		ctx.beginPath();
    	ctx.arc(this.x, this.y, this.radius, 0, Math.PI*2);
    	ctx.fillStyle = "#0095DD";
    	ctx.fill();
    	ctx.closePath();	
	};
}

//the bricks
function Brick(){
	this.x;
    this.y;
    this.lives = 1;
    this.speedUp;
    this.alterPlatormSize;
	this.speedAlter;
	this.teleport;
    this.draw = function(){
        if(this.lives > 0){
			var color = "red";
			if(this.speedUp || this.speedAlter)
				color = "DeepPink";
			if(this.alterPlatformSize)
				color = "green";

			//draw the brick
			ctx.beginPath();
			ctx.rect(this.x, this.y, brickWidth, brickHeight);
			ctx.fillStyle = color;
			ctx.fill();
			ctx.closePath();

			//draw the number of lives of a brick
            ctx.beginPath();
			ctx.font = "15px Arial";
			ctx.fillStyle = "white";
			ctx.fillText(this.lives, (2*this.x + brickWidth)/2 - 5, (2*this.y + brickHeight)/2 + 5);

			ctx.closePath();
	    }
    }
}

function Score(){
	this.score;
	this.game;
	this.maxScore;
	this.maxGame;
}
