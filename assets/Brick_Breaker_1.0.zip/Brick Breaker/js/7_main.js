function mainDraw(){
	switch(screen){
		case 0:
			drawNewGameScreen();
		break;
		case 1:
			drawPlayScreen();

    		brickCollision();
    		ballOutOfBounds();
    	
			isTopScore();
    		isGameOver();
    
			moveBall();
		break;
		case 2:
			drawGameOverScreen();
		break;
		case 3:
			drawHowToPlayScreen();
		break;
		case 4:
			assets.pausescreen.draw();
		break;
		case 5:
			assets.aboutscreen.draw();
		break;
	}
	
    requestAnimationFrame(mainDraw); //repeatedly calls itself
}

canvas.onclick = mouseclick;
loadImages();
resetGame();
mainDraw();
