/*~~~~~COLLISIONS~~~~~*/
function ballOutOfBounds(){
    //collision with platform
	if((ball.x + ball.radius >= platform.posX) &&  
	(ball.x - ball.radius <= platform.posX + platform.width) && 
	(ball.y + ball.radius >= platform.posY)){
		ball.dy *= -1;
        ball.playSound = 1;

        ball.y = ball.prevy;
    }
	else{
	//Does NOT collide with platform
		//collision with ceiling
		if(ball.y - ball.radius <= 0){
			ball.dy *= -1;
            ball.playSound = 1;

            ball.y = ball.prevy;
        }
		
		//collision with the left and right walls
		if(ball.x + ball.radius >= canvas.width || ball.x - ball.radius <= 0){
			ball.dx *= -1;

            ball.x = ball.prevx;
            ball.playSound = 1;
        }
		//IF THE BALL REACHES THE BOTTOM
		if(ball.y + ball.radius >= canvas.height){
			//lose a life
			lives--;
		
			//change the ball position to above the platform
			ball.x = (2*platform.posX + platform.width)/2;
			if(ball.x + ball.radius >= canvas.width) //prevent the ball from crashing constantly against the wall when platform is at max
				ball.x -= ball.radius;
			if(ball.x - ball.radius <= 0)
				ball.x += ball.radius;
 
			ball.y = platform.posY - ball.radius;
			
			//change the speed randomly
			ball.dx = (Math.round(Math.random())*2 -1) * Math.floor(Math.random()*4 +2);
			ball.dy = -Math.floor(Math.random()*4 +2);
		}	
	}

}

function brickCollision(){
    for(r=0; r < array.nRow; r++)
		for(c=0; c < array.nCol; c++){
			var b = array.bricks[r][c]; //'b' will be the current brick (to save space)
			if(b.lives > 0)//if the brick is there
				if((ball.x + ball.radius > b.x) && (ball.x - ball.radius < b.x + brickWidth) && 
				   (ball.y + ball.radius > b.y) && (ball.y - ball.radius < b.y + brickHeight)){ //if collision with a brick
				
                //standard change of direction
				if( ball.x < b.x  && ball.dx > 0){ //hits on the left side of the brick AND it's going right

					ball.dx *= -1;
                    ball.x = ball.prevx;
                }
				else if(ball.x > b.x + brickWidth && ball.dx < 0){ //hits on right side AND going left
					ball.dx *= -1;
					ball.x = ball.prevx;				
				}
				else{
					ball.dy *= -1;
                    ball.y = ball.prevy;
                }
				
				//in case of POWER-UPS
				if(b.speedUp == 1){
					ball.dx *=1.5;
					ball.dy *=1.5;
				}
				
				if(b.speedAlter == 1){
					ball.dx = (Math.round(Math.random()) * 2 - 1) *Math.floor(Math.random()*3 +3);
					ball.dy = (Math.round(Math.random()) * 2 - 1)*Math.floor(Math.random()*3 +3);
				}

				if(b.alterPlatformSize == 2){
					platform.width += 10;
				}
				if(b.alterPlatformSize == 1 && platform.width > 10)
					platform.width -= 10;
				if(b.teleport){
					ball.x = Math.floor(Math.random()*(canvas.width-20))+20;
					ball.y = Math.floor(Math.random()*(canvas.height*0.5 -20) +20);
				}
				
                ball.playSound = 1;
				b.lives--;
				score.score++;
			}
		}	    
}
