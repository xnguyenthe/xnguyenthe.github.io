var screen = 0;
var sound = 1;
var lives;

var score = new Score();

//the platform
var platform = new Platform();

//the ball
var ball = new Ball();

//the array of bricks to be drawn
var array = {
	nRow: 0,
	nCol: 0,
	margin: 0.05 * canvas.width,
	bricks: [],
}

//the bricks
var brickWidth = 80;
var brickHeight = 30;

var assets = {
	background: new Screen(),
	hwtoplscreen: new Screen(),
	pausescreen: new Screen(),
	aboutscreen: new Screen(),
	
	playbutton: new Button(),
	hwtoplbutton: new Button(),
	aboutbutton: new Button(),
	gameoverbutton: new Button(),

	soundon: new Image(),
	soundoff: new Image(),

	gameoverbutton: new Button(),

	sound,
};
